Reading Assessment Evidence
Open index.html in a browser. No server or account is needed.
This is a standalone web course, not a Canvas export. All examples are fictional.
Created with Codex assistance for Grant McCurdy; human content review and learner testing pending. No learner-outcome claims.
Audience: teachers comfortable with percentages, new to data interpretation.
Alignment: compare distributions, distinguish missing evidence, recommend a proportionate action. Each objective has practice with feedback. The final brief uses an evidence/limitation/action/follow-up self-review rubric.
UDL choices: visual and tabular representations, open navigation, retries, prose or bullets, oral rehearsal, no time limit.
Accessibility: semantic headings, labeled inputs, keyboard focus, alternative text, print fallback. No conformance certification or independent screen-reader audit.
The SVGs are editable sources. Regenerate them from this directory with Node: node sources/build_learning_graphics.mjs .
Progress is browser-local when supported. Reset removes this course attempt.
